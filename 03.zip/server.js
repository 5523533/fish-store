const express = require('express');
const app = express();
const port = 3000;
const connectToDatabase = require('./data/db');

// إعدادات الخادم
app.use(express.static('images'));
app.use(express.static('public'));
app.set('views', './views');
app.set('view engine', 'ejs');

// مسار افتراضي
app.get('/', async (req, res) => {
    try {
        const db = await connectToDatabase();
        const products = await db.collection('products').find({}).toArray();
        res.render('index', { products });
    } catch (error) {
        console.error('حدث خطأ أثناء استرجاع المنتجات:', error);
        res.status(500).send('حدث خطأ في الخادم');
    }
});

// مسار لعرض المنتجات
app.get('/products', async (req, res) => {
    try {
        const db = await connectToDatabase();
        const products = await db.collection('products').find({}).toArray();
        res.render('products', { products });
    } catch (error) {
        console.error('حدث خطأ أثناء استرجاع المنتجات:', error);
        res.status(500).send('حدث خطأ في الخادم');
    }
});

// مسار لسلة الشراء
app.get('/cart', (req, res) => {
    res.render('cart');
});

// مسار لتسجيل الدخول
app.get('/login', (req, res) => {
    res.render('login');
});

// مسار للوحة تحكم مالك المتجر
app.get('/admin', (req, res) => {
    res.render('admin');
});

// بدء تشغيل الخادم
app.listen(port, () => {
    console.log(`الخادم قيد التشغيل على المنفذ ${port}`);
});