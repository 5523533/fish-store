// وظيفة لإضافة منتج جديد
function addProduct() {
    // هنا سيتم تنفيذ عملية إضافة منتج جديد
    // على سبيل المثال، يمكن فتح نموذج لإدخال بيانات المنتج
    // ثم إرسال طلب إلى الخادم لتخزين بيانات المنتج في قاعدة البيانات
    console.log("تمت إضافة منتج جديد");
}

// وظيفة لحذف منتج
function deleteProduct(productId) {
    // هنا سيتم تنفيذ عملية حذف منتج
    // على سبيل المثال، يمكن إرسال طلب إلى الخادم لحذف المنتج من قاعدة البيانات
    console.log("تم حذف المنتج " + productId);
}

// وظيفة لعرض قائمة الطلبات
function displayOrders() {
    // هنا سيتم تنفيذ عملية عرض قائمة الطلبات
    // على سبيل المثال، يمكن إرسال طلب إلى الخادم للحصول على قائمة الطلبات
    // ثم عرضها في واجهة المستخدم
    console.log("تم عرض قائمة الطلبات");
}

// إضافة مستمع للأحداث لزر "إضافة منتج"
const addProductButton = document.querySelector(".add-product");
addProductButton.addEventListener("click", addProduct);

// إضافة مستمع للأحداث لأزرار "حذف منتج"
const deleteProductButtons = document.querySelectorAll(".delete-product");
deleteProductButtons.forEach(button => {
    button.addEventListener("click", () => {
        deleteProduct(button.dataset.productId);
    });
});

// إضافة مستمع للأحداث لزر "عرض الطلبات"
const displayOrdersButton = document.querySelector(".display-orders");
displayOrdersButton.addEventListener("click", displayOrders); 