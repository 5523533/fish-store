const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://heshammostafa330:iJF2wfAIwqhPz3uu@cluster0.xqltg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"; // الصق عنوان URI  هنا
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

async function connectToDatabase() {
    try {
        await client.connect();
        console.log("تم الاتصال بقاعدة البيانات بنجاح");
        return client.db("fish_store"); 
    } catch (error) {
        console.error("حدث خطأ أثناء الاتصال بقاعدة البيانات:", error);
        process.exit(1);
    }
}

module.exports = connectToDatabase;